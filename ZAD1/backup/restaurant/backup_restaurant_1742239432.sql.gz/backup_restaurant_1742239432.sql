INSERT INTO `drink` (`id`, `flavor`, `size`) VALUES ('1', 'Lemonade', 'Large');
INSERT INTO `drink` (`id`, `flavor`, `size`) VALUES ('2', 'Water', 'Small');
INSERT INTO `food` (`id`, `name`, `portionSize`) VALUES ('1', 'Pizza', 'Jumbo');
INSERT INTO `food` (`id`, `name`, `portionSize`) VALUES ('2', 'Pasta', 'Small');
